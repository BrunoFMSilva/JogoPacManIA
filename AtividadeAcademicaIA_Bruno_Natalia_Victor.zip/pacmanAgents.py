# pacmanAgents.py
# ---------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

from pacman import Directions
from game import Agent
import random
import game
import util
from searchAgents import PositionSearchProblem

class LeftTurnAgent(game.Agent):
  "An agent that turns left at every opportunity"
  
  def getAction(self, state):
    legal = state.getLegalPacmanActions()
    current = state.getPacmanState().configuration.direction
    if current == Directions.STOP: current = Directions.NORTH
    left = Directions.LEFT[current]
    if left in legal: return left
    if current in legal: return current
    if Directions.RIGHT[current] in legal: return Directions.RIGHT[current]
    if Directions.LEFT[left] in legal: return Directions.LEFT[left]
    return Directions.STOP

class GreedyAgent(Agent):
  def __init__(self, evalFn="scoreEvaluation"):
    self.evaluationFunction = util.lookup(evalFn, globals())
    assert self.evaluationFunction != None
        
  def getAction(self, state):
    # Generate candidate actions
    legal = state.getLegalPacmanActions()
    if Directions.STOP in legal: legal.remove(Directions.STOP)
      
    successors = [(state.generateSuccessor(0, action), action) for action in legal] 
    scored = [(self.evaluationFunction(state), action) for state, action in successors]
    bestScore = max(scored)[0]
    bestActions = [pair[1] for pair in scored if pair[0] == bestScore]
    return random.choice(bestActions)

class PacmanAgent(game.Agent):

    def getPacmanSuccessors(self, legalActions, state): #gera os estados sucessores do pacman
      return [(state.generateSuccessor(self.index, action), action, state.generateSuccessor(self.index, action).getPacmanPosition()) for action in legalActions]
      #retorna uma tupla contendo o estado sucessor, a acao e a poicao do estado sucessor para cada acao valida nas acoes validas
    def getAction(self, state):
        from util import PriorityQueue, Counter, manhattanDistance

        foodGrid = state.getFood() #recebe a matriz de comidas
        foodList = list(foodGrid.asList()) #armazena a matriz em uma lista

        _, nextFood = min([(util.manhattanDistance(state.getPacmanPosition(), comida), comida) for comida in foodList]) 
        #obtem a comida mais proxima do pacman utilizando a distancia de manhattan para cada comida na lista de comidas

        queue = PriorityQueue() #heap de prioridade
        queue.push((state, []), 0) #adiciona o estado na heap
        visitedStates = set() #cria o vetor de estados visitados
        
        while queue.heap: #enquanto a heap nao for vazia
            currentState, actionSequence = queue.pop() #retira a tupla, da heap, contendo o estado atual e a sequencia de acoes

            if currentState.getPacmanPosition() == nextFood: #se a posicao do pacman no estado atual for igual a da proxima comida
              if len(actionSequence) > 0: #se a sequencia de acoes for nao nula 
                return actionSequence[0] #executa a sequencia de acoes 
              else:
                return  currentState.getLegalPacmanActions()[0] #senao, exscolhe a primeira acao possivel
            #seleciona os proximos sucessores 
            for nextState, nextAction, nextPosition in self.getPacmanSuccessors(currentState.getLegalActions(self.index), currentState): 
                if not nextPosition in state.getGhostPositions(): #se nao exise um fantasma na proxima posicao
                  if nextPosition not in visitedStates: #e essa posicao nao pertence aos estados visitados
                    visitedStates.add(nextPosition)  #adiciona-se aos estados visitados a proxima posicao
                    fullAction = actionSequence + [nextAction]  #e atribuida a acao total a sequencia de acoes mais a proxima acao
                    queue.push((nextState, fullAction), len(fullAction) + manhattanDistance(nextFood, state.getPacmanPosition())) 
                    #insere na heap o proximo estado ja calculando a disancia de manhattan para a proxima comida 

        #se nao for possivel utilizar as funcoes acima devido a impossibilidade de usar a busca, o algoritmo procura apenas uma posicao razoavel e a retorna
        for _, action, pacmanNextPosition in self.getPacmanSuccessors(state.getLegalPacmanActions(), state): 
          if pacmanNextPosition not in state.getGhostPositions() and action != 'Stop': #verifica apenas se a proxima posicao do pacman nao e a mesma do fantasma
            return action
        return random.choice(state.getLegalPacmanActions()) #em ultima instancia o algoritmo retorna apenas uma escolha aleatoria

def scoreEvaluation(state):
  return state.getScore()  