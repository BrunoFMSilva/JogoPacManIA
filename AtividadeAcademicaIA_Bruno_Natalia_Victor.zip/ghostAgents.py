# ghostAgents.py
# --------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

from game import Agent
from game import Actions
from game import Directions
import random
from util import manhattanDistance
import util

class GhostAgent( Agent ):
  def __init__( self, index ):
    self.index = index

  def getAction( self, state ):
    dist = self.getDistribution(state)
    if len(dist) == 0: 
      return Directions.STOP
    else:
      return util.chooseFromDistribution( dist )
    
  def getDistribution(self, state):
    "Returns a Counter encoding a distribution over actions from the provided state."
    util.raiseNotDefined()

class RandomGhost( GhostAgent ):
  "A ghost that chooses a legal action uniformly at random."
  def getDistribution( self, state ):
    dist = util.Counter()
    for a in state.getLegalActions( self.index ): dist[a] = 1.0
    dist.normalize()
    return dist

class DirectionalGhost( GhostAgent ):
  "A ghost that prefers to rush Pacman, or flee when scared."
  def __init__( self, index, attackProbability=0.8, scaredFleeProbability=0.8 ):
    self.index = index
    self.attackProbability = attackProbability
    self.scaredFleeProbability = scaredFleeProbability
  
  def getGhostSuccessors(self, legalActions, state):
      return [(state.generateSuccessor(self.index, action), action, state.generateSuccessor(self.index, action).getGhostPosition(self.index)) for action in legalActions]
      
  def getDistribution(self, state):
    
    from util import PriorityQueue, Counter, manhattanDistance

    ghostState = state.getGhostState(self.index) #obtem o estado inicial do fantasma
    legalActions = state.getLegalActions(self.index) #obtem as acoes possiveis 
    isScared = ghostState.scaredTimer > 0 #verifica a quantidde de tempo que os fantasmas estao assustados
    pacmanPosition = state.getPacmanPosition() #obtem a posicao do pacman
    dist = Counter()  

    if not isScared: #se o fantasma nao esta com medo
      queue = PriorityQueue() #cria uma heap
      visitedStates = set() #cria um vetor com estados visitados
      queue.push((state,[]) , 0) #insere na heap o estado

      for elem in state.getGhostPositions(): #para cada elemento das posicoes do fantasma
        if elem != state.getGhostPosition(self.index): 
          visitedStates.add(elem) #adiciona o elemento ao conjunto de visitados, o que permite com que os fantasmas nao procurem o pacman pela mesma rota
      
      while queue.heap: #enquanto a heap nao estiver vazia
        currentState , actionsSequence = queue.pop() #retira a tupla contendo o primeiro estado e sequencia de acoes da heap
        if currentState.getGhostPosition(self.index) == pacmanPosition: # se a posicao dos fantasmas for igual a posicao do pacman o objetivo foi atingido
              if len(actionsSequence): 
                dist[actionsSequence[0]] = 1 
              else:
                dist[nextAction] = 1
              return dist

        visitedStates.add(currentState.getGhostPosition(self.index)) #adiciona o estado atual aos estados visitados

        for nextState, nextAction, nextPosition in self.getGhostSuccessors(currentState.getLegalActions(self.index), currentState): #gera o estado sucessor
          if not nextPosition in visitedStates: # verifica se o estado sucessor nao foi visitado
            fullAction =  actionsSequence + [nextAction] #adiciona a acao do estagio a sequencia de acoes
            queue.push((nextState, fullAction), len(fullAction) + manhattanDistance(nextPosition, pacmanPosition)) # adiciona o estado sucessor a heap calculando sua funcao de avaliacao
     
    sucessors = self.getGhostSuccessors(legalActions, state) # caso o pacman obtenha o poder a acao e alterada para fuga do fantasma
    _, actionFlee = max((manhattanDistance(s[2], pacmanPosition), s[1]) for s in sucessors) #obtem para cada estado s nos sucessores a nova acao
    dist[actionFlee] = 1
    return dist